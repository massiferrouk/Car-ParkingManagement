-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 14, 2022 at 09:33 PM
-- Server version: 5.7.38-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.11

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parking_db`
--
CREATE DATABASE IF NOT EXISTS `parking_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `parking_db`;

-- --------------------------------------------------------

--
-- Table structure for table `etage`
--

DROP TABLE IF EXISTS `etage`;
CREATE TABLE `etage` (
  `id` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `description` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `etage`
--

INSERT INTO `etage` (`id`, `numero`, `description`) VALUES
(1, 1, 'Petite voitures');

-- --------------------------------------------------------

--
-- Table structure for table `operation_parking`
--

DROP TABLE IF EXISTS `operation_parking`;
CREATE TABLE `operation_parking` (
  `id` int(11) NOT NULL,
  `idVehicule` int(11) NOT NULL,
  `idPlaceParking` int(11) NOT NULL,
  `date_heure_entree` datetime NOT NULL,
  `date_heure_sortie` datetime NOT NULL,
  `id_agent_1` int(11) NOT NULL,
  `id_agent_2` int(11) DEFAULT NULL,
  `observation` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `place_parking`
--

DROP TABLE IF EXISTS `place_parking`;
CREATE TABLE `place_parking` (
  `id` int(11) NOT NULL,
  `numero` varchar(5) NOT NULL,
  `type` enum('leger','moyen','lourd') NOT NULL,
  `occupe` tinyint(1) NOT NULL DEFAULT '0',
  `idEtage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `login` varchar(30) NOT NULL,
  `motDePasse` varchar(50) NOT NULL,
  `role` enum('Administrateur','Agent') NOT NULL DEFAULT 'Agent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `prenom`, `login`, `motDePasse`, `role`) VALUES
(1, 'FERROUK', 'Massi', 'massi', '7680085a6a9ede6f820f6fb9d5e43d363f095efc', 'Administrateur'),
(2, 'FERROUKhhhhh', 'Massi', 'tassi2', '1a3da4d3f1871820634bf5e276e852a9121e07a9', 'Administrateur');

-- --------------------------------------------------------

--
-- Table structure for table `vehicule`
--

DROP TABLE IF EXISTS `vehicule`;
CREATE TABLE `vehicule` (
  `id` int(11) NOT NULL,
  `matricule` varchar(15) NOT NULL,
  `type` enum('leger','moyen','lourd') NOT NULL DEFAULT 'leger'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `etage`
--
ALTER TABLE `etage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `operation_parking`
--
ALTER TABLE `operation_parking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idVehicule` (`idVehicule`),
  ADD KEY `idPlaceParking` (`idPlaceParking`),
  ADD KEY `id_agent_1` (`id_agent_1`),
  ADD KEY `id_agent_2` (`id_agent_2`);

--
-- Indexes for table `place_parking`
--
ALTER TABLE `place_parking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idEtage` (`idEtage`);

--
-- Indexes for table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Indexes for table `vehicule`
--
ALTER TABLE `vehicule`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `matricule` (`matricule`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `etage`
--
ALTER TABLE `etage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `operation_parking`
--
ALTER TABLE `operation_parking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `place_parking`
--
ALTER TABLE `place_parking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicule`
--
ALTER TABLE `vehicule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `operation_parking`
--
ALTER TABLE `operation_parking`
  ADD CONSTRAINT `operation_parking_ibfk_1` FOREIGN KEY (`idVehicule`) REFERENCES `vehicule` (`id`),
  ADD CONSTRAINT `operation_parking_ibfk_2` FOREIGN KEY (`idPlaceParking`) REFERENCES `place_parking` (`id`),
  ADD CONSTRAINT `operation_parking_ibfk_3` FOREIGN KEY (`id_agent_1`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `operation_parking_ibfk_4` FOREIGN KEY (`id_agent_2`) REFERENCES `utilisateur` (`id`);

--
-- Constraints for table `place_parking`
--
ALTER TABLE `place_parking`
  ADD CONSTRAINT `place_parking_ibfk_1` FOREIGN KEY (`idEtage`) REFERENCES `etage` (`id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
